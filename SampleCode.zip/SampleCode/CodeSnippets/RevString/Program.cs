﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace RevString
{
    internal class Program
    {
        public string testi;
        static void Main(string[] args)
        {
            ReverseStringWithInbuiltMethod("labolGSIF");
        }

        private static void ReverseStringWithInbuiltMethod(string stringInput)
        {
            //// With Inbuilt Method Array.Reverse Method  
            //char[] charArray = stringInput.ToCharArray();
            //string[] test = { "", "" };
            //test.agg
            //Array.Reverse(charArray.OrderByDescending(x=>x).order;
            //Console.WriteLine(new string(charArray));

            int ab = 1;
            Console.WriteLine(ab);
            Console.WriteLine(++ab);
            Console.WriteLine(ab++);
            Console.WriteLine(ab--);
            Console.WriteLine(--ab);

            string pattern = @"(\d{2}?)([%$])";
            string input = "Price raised to 34$ which is 10% higher than yesterday.";
            MatchCollection matches = Regex.Matches(input, pattern);
            GroupCollection groups = null;
            foreach (Match match in matches)
            {
                groups = match.Groups;
            }

            Console.WriteLine("{0}: {1}", groups[2], groups[1]);
        }
    }
}
