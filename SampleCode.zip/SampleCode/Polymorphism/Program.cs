﻿using System;
using System.Text.RegularExpressions;

namespace CodeSnippet
{
    class Base
    {
        protected Base()
        {
            Console.WriteLine("In Protected Constructor");
        }

        public void f1()
        { 
            Console.WriteLine("f1 of Base");
        }
        public virtual void f2()
        {
            Console.WriteLine("f2 of Base");
        }
        public virtual void f3()
        {
            Console.WriteLine("f3 of Base");
        }
    }
    class Derived : Base
    {
        public new void f1()
        {
            Console.WriteLine("f1 of Derived");
        }
        public override void f2()
        {
            Console.WriteLine("f2 of Derived");
        }
        public new void f3()
        {
            Console.WriteLine("f3 of Derived");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Base b = new Derived();
            b.f1();
            b.f2();
            b.f3();

            Derived d = new Derived();
            d.f1();
            d.f2();
            d.f3();

            Console.ReadLine();
        }
    }
}
