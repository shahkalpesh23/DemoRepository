﻿using System;

namespace CodeSnippet
{    abstract class Base
    {
        public int i;
        public abstract void display();
    }
    class Derived : Base
    {
        public int j;
        public int sum;
        public override void display()
        {
            sum = i + j;
            Console.WriteLine("Value of i is: " + i + "\nValue of j is:" + j);
            Console.WriteLine("Sum is:" + sum);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Base obj = new Derived();
            obj.i = 2;
            Derived obj1 = new Derived();
            obj1.j = 10;
            obj.display();
            Console.ReadLine();
        }
    }
}
