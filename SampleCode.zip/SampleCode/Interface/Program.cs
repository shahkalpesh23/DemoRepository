﻿using System;

namespace CodeSnippet
{
    interface calc
    {
        void cal(int i);
    }
    class displayA : calc
    {
        public int x;
        public void cal(int i)
        {
            x = i * i;
        }
    }
    class displayB : calc
    {
        public int x;
        public void cal(int i)
        {
            x = i / i;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            displayA arr1 = new displayA();
            displayB arr2 = new displayB();
            arr1.x = 0;
            arr2.x = 0;
            arr1.cal(2);
            arr2.cal(2);
            Console.WriteLine("Output is: " + arr1.x + " and " + arr2.x);
            Console.ReadLine();
        }
    }
}
